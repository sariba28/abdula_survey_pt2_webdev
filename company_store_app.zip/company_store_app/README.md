# Northstar Company Store

A small Flask + SQLite example with registration, login, hashed passwords, and a product catalog.

## 1. Requirements
- Python 3.9 or newer
- pip

## 2. Create and activate a virtual environment

macOS / Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows:
```powershell
py -m venv .venv
.venv\Scripts\activate
```

## 3. Install dependencies
```bash
pip install -r requirements.txt
```

## 4. Initialize the database (optional)
```bash
python database.py
```
The app also creates its tables automatically when it starts.

## 5. Set a secret key
For local testing, the app has a development fallback. Before deployment, set a long random secret key.

macOS / Linux:
```bash
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
```

Windows PowerShell:
```powershell
$env:SECRET_KEY = py -c "import secrets; print(secrets.token_hex(32))"
```

## 6. Run the website
```bash
python app.py
```
Open http://127.0.0.1:5000 in your browser. Register an account, log in, and add products.

## How password hashing works
1. A user enters a password and confirms it on the registration page.
2. The server checks that both entries match and meet the minimum length.
3. `generate_password_hash(password)` from Werkzeug creates a salted password hash.
4. Only that hash is saved in the `users.password_hash` database column. The original password is not saved.
5. During login, `check_password_hash(saved_hash, entered_password)` checks whether the entered password matches.
6. The app never decrypts a hash. Hashing is one-way; the salt and algorithm information are stored in the encoded hash.

Do not use plain SHA-256 or MD5 for password storage. Use a password-hashing function designed for passwords, such as Werkzeug's helper, Argon2id, or bcrypt.

## Files
- `app.py` — Flask routes, sessions, form validation, and password hashing.
- `database.py` — SQLite table creation.
- `database.db` — generated automatically when run; intentionally not included in Git.
- `templates/` — login, registration, and main page HTML templates.
- `static/style.css` — page styling.
- `static/logo.svg` — sample company logo; replace it with your own.
- `.gitattributes` — consistent text-file line endings.
- `.gitignore` — excludes local database, secrets, and Python cache files.

## Important before deployment
This is a learning/demo starter. Use HTTPS, a strong environment-provided `SECRET_KEY`, secure cookie settings, rate limiting, backups, and a production WSGI server before putting it on the public internet. Do not run Flask's debug server in production.
