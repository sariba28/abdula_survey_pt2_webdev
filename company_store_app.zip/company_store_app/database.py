"""Database setup helpers for the Company Store app."""
import sqlite3
from pathlib import Path

DATABASE = Path(__file__).with_name("database.db")


def initialize_database():
    """Create the SQLite tables if they do not already exist."""
    with sqlite3.connect(DATABASE) as connection:
        connection.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL CHECK(price >= 0),
                description TEXT NOT NULL
            );
        """)


if __name__ == "__main__":
    initialize_database()
    print(f"Database ready: {DATABASE}")
